#ifndef IMAGES_CHANGE_H
#define IMAGES_CHANGE_H


class Images_Change
{
public:
    Images_Change();
    const char *NextImage();
    /*图片的路径*/
    const char *images[6] = {"QPushButton{border-image: url(:/quanhuang97/quanhuang97.jpg);border:none;color:rgb(255, 255, 255);}","QPushButton{border-image: url(:/cut_fruit/cut_fruit.jpg);border:none;color:rgb(255, 255, 255);}"};
    int index;
};

#endif // IMAGES_CHANGE_H
