#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>        //提供访问串口的功能
#include <QSerialPortInfo>    //提供系统中存在的串口的信息

#include "images_change.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget //父类QWidget,子类Widget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    Images_Change ic;
    ~Widget();

private slots:


    void on_clear_receiver_clicked();

    void on_send_message_clicked();

    void on_close_uart_clicked();

    void on_open_uart_clicked();

    void serialPort_readyRead();

    void on_game_next_clicked();

    void on_game_select_clicked();

private:
    Ui::Widget *ui;//使用 堆 的形式声明对象 ui，需手动删除(delete ui)
    QSerialPort serial;//直接声明,自动删除
};
#endif // WIDGET_H
