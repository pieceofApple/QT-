#include "widget.h"
#include "ui_widget.h"
#include <QMessageBox>
#include <QString>
#include <QLabel>
Widget::Widget(QWidget *parent)//Widget 构造函数
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    /*serialportbox*/
    /*用于存储 自动读取的可用端口*/
    QStringList serialNamePort;
    /*自动读取*/
    foreach (const QSerialPortInfo &info,QSerialPortInfo::availablePorts()) {//自动搜索当前可用串口，返回值为数组（const 可读）
        serialNamePort<<info.portName();
    }
    //加载至serialportbox
    ui->serialportbox->addItems(serialNamePort);
    /**************/

    //连接信号和槽
    QObject::connect(&serial, &QSerialPort::readyRead, this, &Widget::serialPort_readyRead);

    /*按键初始化*/
    ui->game_select->setEnabled(false);
    ui->send_message->setEnabled(false);
}

Widget::~Widget()//Wideget 析构函数
{
    delete ui;
}

//串口接收
void Widget::serialPort_readyRead()
{
    //从接收缓冲区中读取数据
    QByteArray buffer = serial.readAll();
    //从界面中读取以前收到的数据
    QString recv = ui->receiver->toPlainText().toUtf8();

    recv += QString(buffer);
    //清空以前的显示
    ui->receiver->clear();
    //重新显示
    ui->receiver->appendPlainText(recv);
}

void Widget::on_clear_receiver_clicked()
{
    ui->receiver->clear();
}


void Widget::on_send_message_clicked()
{
    //获取界面上的数据并转换成utf8格式的字节流
    QByteArray data = ui->sender->text().toUtf8();
    //qDebug(data);
    serial.write(data);
}


void Widget::on_close_uart_clicked()
{
    //关闭串口
    serial.close();
    //下拉菜单控件使能失能
    ui->serialportbox->setEnabled(true);
    ui->baudrateBox->setEnabled(true);
    ui->open_uart->setEnabled(true);
    ui->close_uart->setEnabled(false);
    ui->game_select->setEnabled(false);
    //发送按键使能
    ui->send_message->setEnabled(false);
}


void Widget::on_open_uart_clicked()
{
    //设置串口名
    serial.setPortName(ui->serialportbox->currentText());
    //设置波特率
    serial.setBaudRate(ui->baudrateBox->currentText().toInt());
    //设置数据位数
    serial.setDataBits(QSerialPort::Data8);//默认8位
    //也可以这样写QSerialPort::DataBits databits;baudRate=QSerialport:Baud115200;也可以直接databits=115200;

    //设置奇偶校验
    serial.setParity(QSerialPort::NoParity);//默认无奇偶校验
    //设置停止位
    serial.setStopBits(QSerialPort::OneStop);//默认一个停止位
    //设置流控制
    serial.setFlowControl(QSerialPort::NoFlowControl);
    //打开串口
    if(!serial.open(QIODevice::ReadWrite))
    {
        QMessageBox::about(NULL,"提示","无法打开串口!");
        return;
    }
    //下拉菜单控件失能
    ui->serialportbox->setEnabled(false);
    ui->baudrateBox->setEnabled(false);
    ui->open_uart->setEnabled(false);
    ui->close_uart->setEnabled(true);
    //发送按键使能
    ui->send_message->setEnabled(true);
    ui->game_select->setEnabled(true);
}


void Widget::on_game_next_clicked()
{
    ui->game_next->setStyleSheet(ic.NextImage());
}


void Widget::on_game_select_clicked()
{
    switch(ic.index)
    {
    case 0:serial.write("0\n");break;//"0"-->水果忍者
    case 1:serial.write("1\n");break;//"1"-->拳皇97
    }
}

